Hello, thank you for installing cube config! Please follow the steps below to run the config, thank you.

1. Extract the file to C:\Program Files (x86)\Steam\steamapps\common\Team Fortress 2\tf\cfg

3. Go to steam launch options and add +exec CubeConfig	

And you're done!

